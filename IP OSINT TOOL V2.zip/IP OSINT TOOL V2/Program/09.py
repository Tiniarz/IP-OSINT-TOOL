import sys
import urllib.request
import json
import time
from colorama import init, Fore

init(autoreset=True)

def main():
    art = """
             ▄████▄   ██▓     ▒█████   █    ██ ▓█████▄ 
            ▒██▀ ▀█  ▓██▒    ▒██▒  ██▒ ██  ▓██▒▒██▀ ██▌
            ▒▓█    ▄ ▒██░    ▒██░  ██▒▓██  ▒██░░██   █▌
            ▒▓▓▄ ▄██▒▒██░    ▒██   ██░▓▓█  ░██░░▓█▄   ▌
            ▒ ▓███▀ ░░██████▒░ ████▓▒░▒▒█████▓ ░▒████▓ 
            ░ ░▒ ▒  ░░ ▒░▓  ░░ ▒░▒░▒░ ░▒▓▒ ▒ ▒  ▒▒▓  ▒ 
            ░  ▒   ░ ░ ▒  ░  ░ ▒ ▒░ ░░▒░ ░ ░  ░ ▒  ▒ 
            ░          ░ ░   ░ ░ ░ ▒   ░░░ ░ ░  ░ ░  ░ 
            ░ ░          ░  ░    ░ ░     ░        ░    
            ░                                   ░      
"""
    for line in art.splitlines():
        print(Fore.RED + line)
        time.sleep(0.05)
        
    ip = input(" Enter Target IP to check for Cloud Hosting: ").strip()
    if not ip:
        print("[-] Invalid IP.")
        return
        
    print(f"\n[*] Querying open-source registration blocks...")
    
    is_cloud = False
    provider_name = "Unknown / Standard ISP / Bare Metal"
    
    try:
        url = f"https://ipapi.co/{ip}/json/"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=8) as response:
            data = json.loads(response.read().decode())
            org = data.get("org", "").lower()
            
            cloud_signatures = {
                "amazon": "Amazon Web Services (AWS)",
                "aws": "Amazon Web Services (AWS)",
                "google": "Google Cloud Platform (GCP)",
                "gcon": "Google Cloud Platform (GCP)",
                "microsoft": "Microsoft Azure",
                "azure": "Microsoft Azure",
                "cloudflare": "Cloudflare Proxy/CDN",
                "digitalocean": "DigitalOcean VPS",
                "linode": "Linode VPS",
                "hetzner": "Hetzner Hosting",
                "ovh": "OVH Hosting"
            }
            
            for check_str, full_name in cloud_signatures.items():
                if check_str in org:
                    is_cloud = True
                    provider_name = full_name
                    break
                    
            print("\n" + "="*45)
            print("          CLOUD SERVICE CLASSIFIER           ")
            print("="*45)
            print(f" Target IP        : {ip}")
            print(f" Cloud Hosted     : {'YES' if is_cloud else 'NO'}")
            print(f" Provider Profile : {provider_name}")
            print(f" Identified Org   : {data.get('org', 'Not Found')}")
            print(f" Location Context : {data.get('city', 'Unknown')}, {data.get('country_name', 'Unknown')}")
            print("="*45)
            
    except Exception as e:
        print("[-] Verification timeout. Run while connected to an online interface.")

if __name__ == "__main__":
    main()