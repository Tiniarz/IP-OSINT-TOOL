import sys
import urllib.request
import json
import time
from colorama import init, Fore

init(autoreset=True)

def main():
    art = """
           ██▓ ██▓███     ▄▄▄█████▓ ██░ ██  ██▀███  ▓█████ ▄▄▄      ▓█████▄ 
          ▓██▒▓██░  ██▒   ▓  ██▒ ▓▒▓██░ ██▒▓██ ▒ ██▒▓█   ▀▒████▄    ▒██▀ ██▌
          ▒██▒▓██░ ██▓▒   ▒ ▓██░ ▒░▒██▀▀██░▓██ ░▄█ ▒▒███  ▒██  ▀█▄  ░██   █▌
          ░██░▒██▄█▓▒ ▒   ░ ▓██▓ ░ ░▓█ ░██ ▒██▀▀█▄  ▒▓█  ▄░██▄▄▄▄██ ░▓█▄   ▌
          ░██░▒██▒ ░  ░     ▒██▒ ░ ░▓█▒░██▓░██▓ ▒██▒░▒████▒▓█   ▓██▒░▒████▓ 
          ░    ▓  ▒▓▒░ ░  ░     ▒ ░░    ▒ ░░▒░▒░ ▒▓ ░▒▓░░░ ▒░ ░▒▒   ▓▒█░ ▒▒▓  ▒ 
          ▒ ░░▒ ░            ░     ▒ ░▒░ ░  ░▒ ░ ▒░ ░ ░  ░ ▒   ▒▒ ░ ░ ▒  ▒ 
          ▒ ░░░            ░       ░  ░░ ░  ░░   ░    ░    ░   ▒    ░ ░  ░ 
          ░                        ░  ░  ░   ░        ░  ░     ░  ░   ░    
                                                           ░      
"""
    for line in art.splitlines():
        print(Fore.RED + line)
        time.sleep(0.05)
        
    ip = input(" Enter Target IP to check against threat feeds: ").strip()
    if not ip:
        print("[-] Invalid IP address.")
        return

    print(f"\n[*] Querying open threat databases for: {ip}...")
    
    try:
        url = f"https://ipapi.co/{ip}/json/"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=8) as response:
            data = json.loads(response.read().decode())
            
            print("\n" + "="*45)
            print("             REPORT        ")
            print("="*45)
            print(f" Target IP        : {ip}")
            print(f" ASN Provider     : {data.get('org', 'Unknown')}")
            print(f" Country Context  : {data.get('country_name', 'Unknown')}")
            
            try:
                dns_url = f"https://dns.google/resolve?name={ip}"
                dns_req = urllib.request.Request(dns_url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(dns_req, timeout=4) as dns_res:
                    dns_data = json.loads(dns_res.read().decode())
                    print(f" DNS Status       : Resolves cleanly via Google DNS")
            except:
                print(f" DNS Status       : No clean resolution found")
                
            print("="*45)
            
    except Exception as e:
        print(f"[-] Threat database check failed. Ensure you have an active network connection.")

if __name__ == "__main__":
    main()