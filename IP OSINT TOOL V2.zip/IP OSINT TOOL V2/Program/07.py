import sys
import urllib.request
import json
import time
from colorama import init, Fore

init(autoreset=True)

def main():
    art = """
            ▄▄▄▄     ▄████  ██▓███      ▄▄▄        ██████  ███▄    █ 
            ▓█████▄  ██▒ ▀█▒▓██░  ██▒   ▒████▄    ▒██    ▒  ██ ▀█   █ 
            ▒██▒ ▄██▒██░▄▄▄░▓██░ ██▓▒   ▒██  ▀█▄  ░ ▓██▄   ▓██  ▀█ ██▒
            ▒██░█▀  ░▓█  ██▓▒██▄█▓▒ ▒   ░██▄▄▄▄██   ▒   ██▒▓██▒  ▐▌██▒
            ░▓█  ▀█▓░▒▓███▀▒▒██▒ ░  ░    ▓█   ▓██▒▒██████▒▒▒██░   ▓██░
            ▒▓███▀▒ ░▒   ▒ ▒▓▒░ ░  ░    ▒▒   ▓▒█░▒ ▒▓▒ ▒ ░░ ▒░   ▒ ▒ 
            ▒░▒   ░   ░   ░ ░▒ ░          ▒   ▒▒ ░░ ░▒  ░ ░░ ░░   ░ ▒░
             ░    ░ ░ ░   ░ ░░            ░   ▒   ░  ░  ░     ░   ░ ░ 
             ░            ░                   ░  ░      ░           ░ 
             ░                                                                                             
"""
    for line in art.splitlines():
        print(Fore.RED + line)
        time.sleep(0.05)
        
    ip = input(" Enter Target IP to map network neighborhood: ").strip()
    if not ip:
        print("[-] Invalid IP.")
        return

    print(f"\n[*] Querying public RIR data and routing subnets...")
    
    try:
        url = f"https://rdap.db.ripe.net/ip/{ip}"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode())
            
            start_ip = data.get("startAddress", "Unknown")
            end_ip = data.get("endAddress", "Unknown")
            net_name = data.get("name", "Unknown")
            country = data.get("country", "Unknown")
            
            print("\n" + "="*45)
            print("         NETWORK NEIGHBORHOOD MAP            ")
            print("="*45)
            print(f" Network Name   : {net_name}")
            print(f" Country Code   : {country}")
            print(f" CIDR Range    : {start_ip} - {end_ip}")
            print("="*45)
            
            print("\n[*] Suggested neighboring targets inside this subnet:")
            base_ip = ".".join(ip.split(".")[:3])
            current_last_octet = int(ip.split(".")[3])
            
            for i in range(current_last_octet - 3, current_last_octet + 4):
                if 0 <= i <= 255:
                    scan_target = f"{base_ip}.{i}"
                    status = "[TARGET]" if scan_target == ip else "        "
                    print(f"  {status} -> {scan_target}")
            print("="*45)
            
    except Exception as e:
        print(f"[-] RDAP/BGP check failed. This IP may belong to a region outside RIPE routing tables.")

if __name__ == "__main__":
    main()