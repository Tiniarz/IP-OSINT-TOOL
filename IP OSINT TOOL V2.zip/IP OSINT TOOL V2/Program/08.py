import sys
import socket
import ssl
import time
from colorama import init, Fore

init(autoreset=True)

def main():
    art = """
                ██████   ██████  ██▓       ▄▄▄█████▓ ██▓      ██████ 
               ▒██    ▒ ▒██    ▒ ▓██▒       ▓  ██▒ ▓▒▓██▒    ▒██    ▒ 
               ░ ▓██▄   ░ ▓██▄   ▒██░       ▒ ▓██░ ▒░▒██░    ░ ▓██▄   
               ▒   ██▒  ▒   ██▒▒██░       ░ ▓██▓ ░ ▒██░      ▒   ██▒
               ▒██████▒▒▒██████▒▒░██████▒     ▒██▒ ░ ░██████▒▒██████▒▒
               ▒ ▒▓▒ ▒ ░▒ ▒▓▒ ▒ ░░ ▒░▓  ░     ▒ ░░   ░ ▒░▓  ░▒ ▒▓▒ ▒ ░
               ░ ░▒  ░ ░░ ░▒  ░ ░░ ░ ▒  ░       ░    ░ ░ ▒  ░░ ░▒  ░ ░
               ░  ░  ░  ░  ░  ░    ░ ░        ░        ░ ░   ░  ░  ░  
               ░        ░      ░  ░                ░  ░      ░  
                                                       
"""
    for line in art.splitlines():
        print(Fore.RED + line)
        time.sleep(0.05)
        
    ip = input(" Enter Target IP for SSL/TLS scraping: ").strip()
    port_input = input(" Enter Port [Default 443]: ").strip()
    
    port = int(port_input) if port_input.isdigit() else 443
    
    print(f"\n[*] Connecting to {ip}:{port} over native SSL/TLS...")
    
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    
    try:
        with socket.create_connection((ip, port), timeout=8) as sock:
            with context.wrap_socket(sock, server_hostname=ip) as ssock:
                cert = ssock.getpeercert(binary_form=True)
                x509 = ssl.DER_cert_to_PEM_cert(cert)
                
                print("\n" + "="*45)
                print("         SSL/TLS DISCOVERED DOMAINS          ")
                print("="*45)
                
                decoded_cert = ssock.getpeercert()
                found_domains = False
                
                if "subjectAltName" in decoded_cert:
                    for type_name, value in decoded_cert["subjectAltName"]:
                        if type_name == "DNS":
                            print(f" [Found Domain] -> {value}")
                            found_domains = True
                            
                if "subject" in decoded_cert:
                    for item in decoded_cert["subject"]:
                        for entry in item:
                            if entry[0] == "commonName":
                                print(f" [Common Name]  -> {entry[1]}")
                                found_domains = True
                                
                if not found_domains:
                    print("[-] Connection succeeded, but no hidden hostnames found in local handshake.")
                print("="*45)
                
    except Exception as e:
        print(f"[-] Could not establish direct SSL/TLS connection to {ip}:{port}")

if __name__ == "__main__":
    main()